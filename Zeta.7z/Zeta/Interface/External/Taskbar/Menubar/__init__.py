from .Program import ProgramMenu
from .Hacking import HackingMenu
from .File import FileMenu
from .Network import NetworkMenu
from .Code import CodeMenu
from .RE import REMenu
from .Forensics import ForensicsMenu