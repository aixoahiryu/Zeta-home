from .Icon import Load
from . import Common